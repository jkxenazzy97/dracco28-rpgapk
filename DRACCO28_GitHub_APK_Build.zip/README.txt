DRACCO28 RPG Android project
============================

This is an Android Studio project wrapper for the DRACCO28 RPG HTML app.
It is NOT a compiled APK.

Build APK:
1. Install Android Studio on a computer.
2. Open this folder (DRACCO28_Android) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The APK will be under app/build/outputs/apk/debug/app-debug.apk.

Package ID: com.dracco28.rpg
App name: DRACCO28 RPG

Note: The existing HTML app stores demo accounts/data locally in the browser/WebView.
It is not a secure production authentication backend and does not sync between devices.
